# GPS Poids Lourd — projet Android V1.0

Projet Android Kotlin/Jetpack Compose préparé pour :
- accueil
- carte interactive OpenStreetMap dans WebView
- demande de localisation GPS
- recherche d'adresse via Nominatim
- calcul d'itinéraire via OSRM
- profil camion : hauteur, largeur, longueur, poids, essieux, ADR
- compteur de conduite
- structure prête pour brancher ensuite un vrai moteur de routage PL

## Limites importantes
Cette V1 n'est PAS encore un GPS poids lourd professionnel certifié.
OSRM est utilisé ici pour démontrer le flux de navigation routière ; il ne prend pas en charge à lui seul toutes les contraintes PL demandées.
Nominatim et les tuiles OpenStreetMap sont des services publics soumis à leurs politiques d'utilisation.

Pour la version réellement professionnelle, il faudra brancher :
- un fournisseur de données/routage poids lourd
- restrictions de hauteur, poids, largeur, longueur
- restrictions ADR
- trafic
- incidents/travaux
- données de parkings PL
- moteur de règles temps de conduite/repo
- guidage vocal et navigation en arrière-plan
- cache/offline et gestion des quotas/API

## Compilation
Le système Android/Gradle compile le code et le package en APK. Android Studio est l'IDE officiel et Gradle est le système de build utilisé par Android.
