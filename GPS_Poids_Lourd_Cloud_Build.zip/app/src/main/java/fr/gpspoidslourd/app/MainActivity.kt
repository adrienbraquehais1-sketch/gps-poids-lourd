package fr.gpspoidslourd.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import org.json.JSONObject

data class TruckProfile(
    val height: String = "4.00",
    val width: String = "2.55",
    val length: String = "16.50",
    val weight: String = "44",
    val axles: String = "5",
    val adr: Boolean = false
)

class MainActivity : ComponentActivity() {
    private var locationGranted = false

    private val locationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            locationGranted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            locationPermissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }
        setContent { GPSPoidsLourdApp() }
    }

    @Composable
    fun GPSPoidsLourdApp() {
        var page by remember { mutableStateOf("Accueil") }
        var truck by remember { mutableStateOf(TruckProfile()) }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("Accueil" to "⌂", "Carte" to "⌖", "Camion" to "🚛", "Conduite" to "⏱").forEach {
                        NavigationBarItem(
                            selected = page == it.first,
                            onClick = { page = it.first },
                            icon = { Text(it.second, fontSize = 20.sp) },
                            label = { Text(it.first) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (page) {
                    "Accueil" -> HomeScreen(truck) { page = it }
                    "Carte" -> MapScreen(truck)
                    "Camion" -> TruckScreen(truck) { truck = it }
                    else -> DrivingScreen()
                }
            }
        }
    }

    @Composable
    fun Header(title: String, subtitle: String? = null) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text(title, fontSize = 27.sp, color = Color(0xFF0B5CAD))
            if (subtitle != null) Text(subtitle, fontSize = 14.sp)
        }
    }

    @Composable
    fun HomeScreen(truck: TruckProfile, go: (String) -> Unit) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Header("GPS POIDS LOURD", "Navigation camion — version 1.0")
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("🚛 Profil actif", fontSize = 20.sp)
                    Text("${truck.height} m • ${truck.width} m • ${truck.length} m • ${truck.weight} t")
                    Text("${truck.axles} essieux • ADR : ${if (truck.adr) "Oui" else "Non"}")
                }
            }
            Button(
                Modifier.fillMaxWidth().height(58.dp),
                onClick = { go("Carte") }
            ) { Text("DÉMARRER LA NAVIGATION") }

            OutlinedButton(Modifier.fillMaxWidth(), onClick = { go("Camion") }) {
                Text("Modifier le camion")
            }
            OutlinedButton(Modifier.fillMaxWidth(), onClick = { go("Conduite") }) {
                Text("Voir les temps de conduite")
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Fonctions préparées", fontSize = 18.sp)
                    Text("• Carte interactive et position GPS")
                    Text("• Profil camion")
                    Text("• Recherche et itinéraire")
                    Text("• Compteur de conduite")
                    Text("• Architecture prête pour restrictions PL, trafic et aires")
                }
            }
            Text(
                "Important : le moteur d’itinéraire intégré à cette V1 utilise un routage routier générique. Il ne doit pas encore être considéré comme un routage poids lourd certifié.",
                fontSize = 12.sp
            )
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    fun MapScreen(truck: TruckProfile) {
        var destination by remember { mutableStateOf("") }
        var message by remember { mutableStateOf("Position GPS en attente…") }
        var webRef by remember { mutableStateOf<WebView?>(null) }

        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            webRef = this
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.cacheMode = WebSettings.LOAD_DEFAULT
                            webViewClient = WebViewClient()
                            addJavascriptInterface(object {
                                @JavascriptInterface
                                fun status(text: String) { message = text }
                            }, "AndroidBridge")
                            loadUrl("file:///android_asset/map.html")
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
            Column(
                Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(message, fontSize = 12.sp)
                OutlinedTextField(
                    destination,
                    { destination = it },
                    Modifier.fillMaxWidth(),
                    label = { Text("Destination (adresse ou ville)") },
                    singleLine = true
                )
                Button(
                    Modifier.fillMaxWidth(),
                    enabled = destination.isNotBlank(),
                    onClick = {
                        val safe = JSONObject.quote(destination)
                        webRef?.evaluateJavascript("routeTo($safe);", null)
                    }
                ) { Text("CALCULER L’ITINÉRAIRE") }
                Text(
                    "Profil : ${truck.height} m • ${truck.weight} t • ${truck.length} m",
                    fontSize = 12.sp
                )
            }
        }
    }

    @Composable
    fun TruckScreen(truck: TruckProfile, save: (TruckProfile) -> Unit) {
        var h by remember(truck) { mutableStateOf(truck.height) }
        var w by remember(truck) { mutableStateOf(truck.width) }
        var l by remember(truck) { mutableStateOf(truck.length) }
        var weight by remember(truck) { mutableStateOf(truck.weight) }
        var axles by remember(truck) { mutableStateOf(truck.axles) }
        var adr by remember(truck) { mutableStateOf(truck.adr) }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Header("🚛 Profil camion", "Ces paramètres seront utilisés par le moteur PL lorsqu’il sera connecté.")
            listOf(
                "Hauteur (m)" to h,
                "Largeur (m)" to w,
                "Longueur (m)" to l,
                "Poids total (t)" to weight,
                "Nombre d’essieux" to axles
            ).forEach { (label, value) ->
                OutlinedTextField(
                    value,
                    { v ->
                        when (label) {
                            "Hauteur (m)" -> h = v
                            "Largeur (m)" -> w = v
                            "Longueur (m)" -> l = v
                            "Poids total (t)" -> weight = v
                            else -> axles = v
                        }
                    },
                    Modifier.fillMaxWidth(),
                    label = { Text(label) },
                    singleLine = true
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(adr, { adr = it })
                Text("Transport ADR")
            }
            Button(
                Modifier.fillMaxWidth(),
                onClick = { save(TruckProfile(h, w, l, weight, axles, adr)) }
            ) { Text("ENREGISTRER") }
        }
    }

    @Composable
    fun DrivingScreen() {
        var running by remember { mutableStateOf(false) }
        var seconds by remember { mutableLongStateOf(0L) }

        LaunchedEffect(running) {
            while (running) {
                delay(1000)
                seconds++
            }
        }

        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60

        Column(
            Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Header("⏱ Temps de conduite", "Compteur de session")
            Card(Modifier.fillMaxWidth()) {
                Column(
                    Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("%02d:%02d:%02d".format(h, m, s), fontSize = 44.sp)
                    Text(if (running) "Conduite en cours" else "Compteur arrêté")
                }
            }
            Button(
                Modifier.fillMaxWidth().height(55.dp),
                onClick = { running = !running }
            ) { Text(if (running) "PAUSE" else "DÉMARRER") }
            OutlinedButton(
                Modifier.fillMaxWidth(),
                onClick = { running = false; seconds = 0L }
            ) { Text("RÉINITIALISER") }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Tableau conducteur", fontSize = 18.sp)
                    Text("Conduite : ${"%02d:%02d:%02d".format(h, m, s)}")
                    Text("Pause restante : —")
                    Text("Conduite journalière : —")
                    Text("Conduite hebdomadaire : —")
                    Text("Repos : —")
                }
            }
            Text(
                "La V1 fournit un chronomètre de session. Le calcul réglementaire complet des pauses, repos et semaines doit être relié à un moteur de règles validé avant utilisation professionnelle.",
                fontSize = 12.sp
            )
        }
    }
}
